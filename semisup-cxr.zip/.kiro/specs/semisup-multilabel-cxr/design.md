# Design Document: Semi-Supervised Multi-Label CXR Classification

## Overview

This design describes a modular Python pipeline for low-label multi-label chest X-ray classification using CheXpert with 6 pathology labels. The system supports 4 experimental settings — supervised baseline, LVM-Med fine-tuning, class-wise pseudo-labeling, and uncertainty-filtered pseudo-labeling — across 3 labeled ratios (5%, 10%, 20%).

The pipeline is config-driven (YAML), checkpoint-aware, and designed to run in Google Colab with Google Drive persistence. All modules are decoupled so Phase 2 extensions (PAUPL, asymmetric thresholding, co-occurrence filtering, external validation) can be added without architectural changes.

### Key Design Decisions

| Decision | Choice | Rationale |
|---|---|---|
| Framework | PyTorch + torchvision | Standard for medical imaging research |
| Config format | YAML via `dataclasses` + `dacite` | Type-safe, no heavy dependency |
| Pseudo-label policy | Positive-only (Phase 1) | Simpler, avoids noisy negatives |
| Uncertainty metric | Predictive Entropy | Well-understood, single scalar per class |
| Student init | Retrain from scratch (not warm-start) | Cleaner experimental comparison |
| Checkpoint policy | Best (val macro-AUROC) + Last | Standard practice |
| Split strategy | Iterative stratified sampling | Handles multi-label imbalance |
| Normalization | Backbone-specific, recorded in config | Required for LVM-Med compatibility |
| Resume policy | Explicit (user-specified path) | Simpler than auto-resume for Colab |

## Architecture

### Folder Structure

```
semisup-cxr/
├── configs/                          # YAML config templates
│   ├── supervised_baseline.yaml
│   ├── lvmmed_finetune.yaml
│   ├── pseudo_label.yaml
│   └── uncertainty_filter.yaml
├── src/
│   ├── __init__.py
│   ├── config.py                     # Config dataclass + loader
│   ├── data/
│   │   ├── __init__.py
│   │   ├── chexpert_dataset.py       # CheXpert Dataset class
│   │   ├── split_generator.py        # Low-label split logic
│   │   ├── transforms.py             # Augmentation + normalization
│   │   └── combined_dataset.py       # Labeled + pseudo-labeled merge
│   ├── models/
│   │   ├── __init__.py
│   │   ├── backbone_factory.py       # Backbone registry + loader
│   │   └── classifier.py             # Multi-label classifier head
│   ├── training/
│   │   ├── __init__.py
│   │   ├── trainer.py                # Core training loop
│   │   └── losses.py                 # BCE loss (+ future loss variants)
│   ├── pseudo_labeling/
│   │   ├── __init__.py
│   │   ├── teacher_inference.py      # Teacher forward pass on unlabeled
│   │   ├── threshold_strategy.py     # Base class + PositiveOnly strategy
│   │   ├── mc_dropout.py             # MC Dropout uncertainty estimation
│   │   └── artifact_io.py            # Save/load pseudo-label artifacts
│   ├── evaluation/
│   │   ├── __init__.py
│   │   ├── metrics.py                # AUROC, F1, mAP computation
│   │   ├── evaluator.py              # Standalone evaluation runner
│   │   └── reporting.py              # Plots + tables generation
│   └── utils/
│       ├── __init__.py
│       ├── seed.py                   # Reproducibility seed setting
│       ├── checkpoint.py             # Save/load checkpoints
│       ├── logging_utils.py          # Logging setup + git hash
│       └── sanity_checks.py          # Component validation checks
├── notebooks/
│   └── colab_runner.ipynb            # Colab entry point
├── scripts/
│   ├── train.py                      # CLI training entry point
│   ├── generate_pseudo_labels.py     # CLI pseudo-label generation
│   ├── evaluate.py                   # CLI evaluation entry point
│   └── generate_splits.py           # CLI split generation
├── outputs/                          # Default output root (configurable)
│   ├── splits/
│   ├── checkpoints/
│   ├── pseudo_labels/
│   ├── results/
│   └── plots/
└── requirements.txt
```

### Module Dependency Graph

```mermaid
graph TD
    CONFIG[config.py] --> DATA[data/]
    CONFIG --> MODELS[models/]
    CONFIG --> TRAINING[training/]
    CONFIG --> PSEUDO[pseudo_labeling/]
    CONFIG --> EVAL[evaluation/]
    CONFIG --> UTILS[utils/]

    DATA --> TRAINING
    MODELS --> TRAINING
    MODELS --> PSEUDO
    DATA --> PSEUDO
    TRAINING --> PSEUDO
    
    MODELS --> EVAL
    DATA --> EVAL
    
    UTILS --> DATA
    UTILS --> TRAINING
    UTILS --> EVAL
    UTILS --> PSEUDO
```

### Execution Flow per Experimental Setting

```mermaid
flowchart LR
    subgraph Settings 1-2: Supervised / LVM-Med
        A1[Load Config] --> A2[Load Data + Split]
        A2 --> A3[Train on Labeled_Subset]
        A3 --> A4[Evaluate on Val]
    end

    subgraph Setting 3: Pseudo-Labeling
        B1[Load Config] --> B2[Load Data + Split]
        B2 --> B3[Train Teacher on Labeled_Subset]
        B3 --> B4[Teacher Inference on Unlabeled]
        B4 --> B5[Apply Confidence Thresholds]
        B5 --> B6[Save Pseudo-Label Artifacts]
        B6 --> B7[Retrain Student on Labeled + Pseudo]
        B7 --> B8[Evaluate on Val]
    end

    subgraph Setting 4: Uncertainty Filtering
        C1[Load Config] --> C2[Load Data + Split]
        C2 --> C3[Train Teacher on Labeled_Subset]
        C3 --> C4[MC Dropout Inference on Unlabeled]
        C4 --> C5[Apply Confidence + Uncertainty Thresholds]
        C5 --> C6[Save Pseudo-Label Artifacts]
        C6 --> C7[Retrain Student on Labeled + Pseudo]
        C7 --> C8[Evaluate on Val]
    end
```

## Components and Interfaces

### 1. Configuration System (`src/config.py`)

**Validates: Requirements 9, 10, 10A, 13.4**

```python
@dataclass
class DataConfig:
    dataset_path: str                    # Root path to CheXpert
    train_csv: str                       # Relative path to train.csv
    valid_csv: str                       # Relative path to valid.csv
    label_set: List[str]                 # 6 target labels
    uncertain_policy: str                # "zeros" | "ones"
    view_policy: str                     # "frontal_only" | "all"
    image_size: int                      # e.g., 224
    num_workers: int

@dataclass
class SplitConfig:
    labeled_ratio: float                 # 0.05, 0.10, 0.20
    seed: int
    splits_dir: str                      # Where to save/load split metadata
    min_positive_per_class: int          # Minimum positives required (default 1)

@dataclass
class ModelConfig:
    backbone: str                        # "resnet50_imagenet" | "resnet50_lvmmed"
    pretrained_weights_path: Optional[str]
    num_classes: int                     # 6
    dropout_rate: float
    normalization_mean: List[float]      # Backbone-specific
    normalization_std: List[float]

@dataclass
class TrainingConfig:
    learning_rate: float
    batch_size: int
    num_epochs: int
    optimizer: str                       # "adam" | "sgd"
    weight_decay: float
    scheduler: Optional[str]             # "cosine" | "step" | None
    resume_checkpoint: Optional[str]     # Explicit resume path

@dataclass
class PseudoLabelConfig:
    enabled: bool
    confidence_thresholds: Dict[str, float]  # Per-class thresholds
    pseudo_label_policy: str                 # "positive_only" | "positive_negative"
    student_init: str                        # "from_scratch" | "warm_start"
    student_pretrained_weights_path: Optional[str]

@dataclass
class UncertaintyConfig:
    enabled: bool
    mc_dropout_passes: int               # Number of stochastic forward passes
    uncertainty_metric: str              # "predictive_entropy" | "variance"
    uncertainty_thresholds: Dict[str, float]  # Per-class uncertainty thresholds

@dataclass
class ExperimentConfig:
    experiment_name: str
    setting: str                         # "supervised" | "lvmmed" | "pseudo_label" | "uncertainty_filter"
    data: DataConfig
    split: SplitConfig
    model: ModelConfig
    training: TrainingConfig
    pseudo_label: PseudoLabelConfig
    uncertainty: UncertaintyConfig
    output_dir: str
    optional_metrics: List[str]          # ["macro_f1", "map"]
    git_commit: Optional[str]            # Auto-populated at runtime
```

Config loading: `load_config(yaml_path: str) -> ExperimentConfig` using `dacite.from_dict()` with YAML parsed by `PyYAML`.

### 2. Data Pipeline (`src/data/`)

**Validates: Requirements 1, 1A, 2, 13**

#### `CheXpertDataset(torch.utils.data.Dataset)`

- Constructor: `__init__(csv_path, image_root, label_set, uncertain_policy, view_policy, transform)`
- Loads CSV, filters to `label_set` columns, applies `uncertain_policy` mapping (-1 → 0 or 1), filters views per `view_policy`
- `__getitem__` returns `(image_tensor, label_vector, sample_index)`
- `label_vector` is a `torch.FloatTensor` of shape `(6,)` with values in {0, 1}

#### `SplitGenerator`

- `generate_split(dataset, labeled_ratio, seed, splits_dir) -> SplitMetadata`
- Uses `iterstrat.ml_stratifiers.MultilabelStratifiedShuffleSplit` for iterative stratified sampling
- Persists split as JSON: `{seed, labeled_ratio, labeled_indices: [...], unlabeled_indices: [...]}`
- On load: checks file exists → loads and validates → returns indices
- Validates minimum positive count per class; retries with offset seed if violated; raises `SplitGenerationError` after max retries

#### `CombinedDataset(torch.utils.data.Dataset)`

- Merges labeled samples (ground-truth labels) with pseudo-labeled samples
- Constructor: `__init__(labeled_dataset, pseudo_label_df, label_set, transform)`
- Ground-truth labels are never overwritten by pseudo-labels (Req 13.1)
- For pseudo-labeled samples, only classes with accepted pseudo-labels contribute to loss (via a mask tensor)
- `__getitem__` returns `(image_tensor, label_vector, loss_mask, is_pseudo)`

#### `transforms.py`

- `get_train_transform(model_config) -> torchvision.transforms.Compose`
- `get_eval_transform(model_config) -> torchvision.transforms.Compose`
- Train: Resize → RandomHorizontalFlip → RandomRotation(±10°) → ToTensor → Normalize(mean, std)
- Eval: Resize → ToTensor → Normalize(mean, std)
- Normalization params come from `ModelConfig` (backbone-specific)

### 3. Model Architecture (`src/models/`)

**Validates: Requirements 3, 4, 11.3, 16.2**

#### `BackboneFactory`

```python
_REGISTRY: Dict[str, Callable] = {}

def register_backbone(name: str, loader: Callable):
    _REGISTRY[name] = loader

def create_backbone(name: str, weights_path: Optional[str]) -> nn.Module:
    return _REGISTRY[name](weights_path)
```

Built-in registrations:
- `"resnet50_imagenet"`: loads `torchvision.models.resnet50(weights=ResNet50_Weights.IMAGENET1K_V1)`, removes final FC
- `"resnet50_lvmmed"`: loads ResNet50 architecture, loads state dict from `weights_path`, removes final FC

#### `MultiLabelClassifier(nn.Module)`

```python
class MultiLabelClassifier(nn.Module):
    def __init__(self, backbone: nn.Module, feature_dim: int, num_classes: int, dropout_rate: float):
        self.backbone = backbone
        self.dropout = nn.Dropout(dropout_rate)
        self.classifier = nn.Linear(feature_dim, num_classes)
    
    def forward(self, x) -> torch.Tensor:
        features = self.backbone(x)          # (B, feature_dim)
        features = self.dropout(features)
        logits = self.classifier(features)   # (B, num_classes)
        return logits                        # Raw logits; sigmoid applied in loss/eval
```

Feature dim: 2048 for ResNet50.

### 4. Training Loop (`src/training/trainer.py`)

**Validates: Requirements 3, 3A, 4, 5.6, 12.4, 14**

```python
class Trainer:
    def __init__(self, config: ExperimentConfig, model, train_loader, val_loader, device):
        ...
    
    def train(self) -> TrainResult:
        """Full training loop with epoch-level logging and checkpointing."""
        for epoch in range(start_epoch, config.training.num_epochs):
            train_loss = self._train_epoch(epoch)
            val_metrics = self._validate(epoch)
            self._log_epoch(epoch, train_loss, val_metrics)
            self._save_checkpoint(epoch, val_metrics)  # Best + Last
        return TrainResult(best_epoch, best_macro_auroc, per_class_auroc)
    
    def _train_epoch(self, epoch) -> float:
        """Single epoch: forward, BCE loss (masked for pseudo-labels), backward."""
    
    def _validate(self, epoch) -> Dict:
        """Compute macro-AUROC and per-class AUROC on val set."""
    
    def _save_checkpoint(self, epoch, val_metrics):
        """Save best_checkpoint.pt and last_checkpoint.pt."""
```

Loss computation:
- Standard BCE: `F.binary_cross_entropy_with_logits(logits, labels, reduction='none')`
- For `CombinedDataset` batches: multiply element-wise by `loss_mask` before mean reduction
- This ensures pseudo-labeled samples only contribute loss for accepted classes

Resume logic:
- If `config.training.resume_checkpoint` is set, load model + optimizer + epoch from that path
- No auto-detection; user must specify the path explicitly

### 5. Pseudo-Labeling Pipeline (`src/pseudo_labeling/`)

**Validates: Requirements 5, 6, 6A, 13.2**

#### Threshold Strategy Interface

```python
class ThresholdStrategy(ABC):
    @abstractmethod
    def accept(self, probabilities: np.ndarray, uncertainties: Optional[np.ndarray],
               class_names: List[str]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Args:
            probabilities: (N, C) predicted probabilities
            uncertainties: (N, C) uncertainty values or None
            class_names: list of C class names
        Returns:
            pseudo_labels: (N, C) accepted pseudo-labels (0/1), NaN for rejected
            rejection_mask: (N, C) boolean mask, True = rejected
        """

class PositiveOnlyStrategy(ThresholdStrategy):
    """Accept pseudo-positive labels where prob > threshold; reject all else."""
    def __init__(self, confidence_thresholds: Dict[str, float]):
        ...

class UncertaintyFilteredStrategy(ThresholdStrategy):
    """Accept pseudo-positive where prob > conf_threshold AND uncertainty < unc_threshold."""
    def __init__(self, confidence_thresholds: Dict[str, float],
                 uncertainty_thresholds: Dict[str, float]):
        ...
```

#### Teacher Inference (`teacher_inference.py`)

```python
def run_teacher_inference(
    model: nn.Module,
    dataloader: DataLoader,
    device: torch.device
) -> Tuple[np.ndarray, np.ndarray]:
    """Standard forward pass. Returns (sample_indices, probabilities)."""
```

#### MC Dropout (`mc_dropout.py`)

```python
def run_mc_dropout_inference(
    model: nn.Module,
    dataloader: DataLoader,
    device: torch.device,
    num_passes: int,
    uncertainty_metric: str = "predictive_entropy"
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Returns (sample_indices, mean_probabilities, uncertainties).
    Enables dropout at inference via model.train() on dropout layers only.
    """

def compute_predictive_entropy(mc_probs: np.ndarray) -> np.ndarray:
    """
    mc_probs: (T, N, C) — T passes, N samples, C classes
    Returns: (N, C) predictive entropy per class
    H = -[p*log(p) + (1-p)*log(1-p)] where p = mean over T passes
    """
```

#### Artifact I/O (`artifact_io.py`)

```python
def save_pseudo_label_artifact(
    artifact_dir: str,
    sample_indices: np.ndarray,
    probabilities: np.ndarray,
    pseudo_labels: np.ndarray,
    rejection_mask: np.ndarray,
    uncertainties: Optional[np.ndarray],
    config: ExperimentConfig
) -> str:
    """Save as CSV + config JSON. Returns artifact path."""

def load_pseudo_label_artifact(artifact_path: str) -> pd.DataFrame:
    """Load previously saved artifact for analysis."""
```

Artifact directory structure:
```
outputs/pseudo_labels/{setting}/{ratio}_{seed}/
├── pseudo_labels.csv       # sample_id, prob_per_class, label_per_class, rejected, uncertainty
└── config.json             # Copy of ExperimentConfig used
```

### 6. Evaluation Pipeline (`src/evaluation/`)

**Validates: Requirements 7, 8**

#### `metrics.py`

```python
def compute_auroc(y_true: np.ndarray, y_score: np.ndarray, label_names: List[str]) -> Dict:
    """Returns {'macro_auroc': float, 'per_class_auroc': {name: float}}"""

def compute_optional_metrics(y_true, y_pred, y_score, label_names, metrics_list) -> Dict:
    """Compute macro_f1, mAP if requested."""
```

#### `evaluator.py`

```python
def evaluate_checkpoint(
    checkpoint_path: str,
    config: ExperimentConfig,
    device: torch.device
) -> Dict:
    """Load model from checkpoint, run on val set, return all metrics."""
```

#### `reporting.py`

```python
def generate_comparison_bar_chart(results_df, output_dir): ...
def generate_per_class_auroc_plot(results_df, output_dir): ...
def generate_results_table(results_df, output_dir, format="markdown"): ...
```

All plots saved as PNG. Tables saved as Markdown and optionally LaTeX.

### 7. Utilities (`src/utils/`)

**Validates: Requirements 10, 10A, 14, 15A**

#### `seed.py`
```python
def set_all_seeds(seed: int):
    """Set Python, NumPy, PyTorch, CUDA seeds. Warn if deterministic mode unavailable."""
```

#### `checkpoint.py`
```python
def save_checkpoint(path, model, optimizer, epoch, config, val_metrics, extra_meta=None): ...
def load_checkpoint(path, model, optimizer=None, device='cpu') -> Dict: ...
```

Checkpoint contents: `{model_state_dict, optimizer_state_dict, epoch, config, val_metrics, seed, git_commit, library_versions}`

#### `logging_utils.py`
```python
def setup_logging(output_dir, experiment_name) -> logging.Logger: ...
def get_git_commit() -> Optional[str]: ...
def log_library_versions() -> Dict[str, str]: ...
```

#### `sanity_checks.py`
```python
def check_data_loading(dataset) -> bool: ...
def check_split_validity(split_meta, dataset_size, labeled_ratio) -> bool: ...
def check_training_step(model, sample_batch, device) -> bool: ...
def check_evaluation(evaluator, model, val_loader) -> bool: ...
```

## Data Models

### Split Metadata (JSON)

```json
{
  "labeled_ratio": 0.05,
  "seed": 42,
  "total_train_size": 191027,
  "labeled_size": 9551,
  "unlabeled_size": 181476,
  "labeled_indices": [0, 5, 12, ...],
  "unlabeled_indices": [1, 2, 3, ...],
  "per_class_positive_counts": {
    "Cardiomegaly": 1200,
    "Pleural Effusion": 2400,
    ...
  },
  "generation_timestamp": "2025-01-15T10:30:00Z"
}
```

### Checkpoint Metadata

```json
{
  "epoch": 15,
  "val_macro_auroc": 0.823,
  "val_per_class_auroc": {"Cardiomegaly": 0.85, ...},
  "seed": 42,
  "git_commit": "abc123def",
  "library_versions": {"torch": "2.1.0", "numpy": "1.24.0", "python": "3.10.12"},
  "config": { ... }
}
```

### Pseudo-Label Artifact (CSV columns)

| Column | Type | Description |
|---|---|---|
| sample_index | int | Index into original training set |
| prob_{class} | float | Teacher predicted probability per class |
| pseudo_{class} | float/NaN | Accepted pseudo-label (1.0) or NaN (rejected) |
| rejected_{class} | bool | Whether pseudo-label was rejected |
| uncertainty_{class} | float/NaN | Uncertainty value (if uncertainty filtering enabled) |
| rejection_reason_{class} | str | "confidence" / "uncertainty" / "accepted" |

### Evaluation Results (CSV)

| Column | Type |
|---|---|
| setting | str |
| labeled_ratio | float |
| seed | int |
| macro_auroc | float |
| auroc_{class} | float (per class) |
| macro_f1 | float (optional) |
| map | float (optional) |

### YAML Config Template (Supervised Baseline Example)

```yaml
experiment_name: "supervised_baseline_5pct_seed42"
setting: "supervised"

data:
  dataset_path: "/content/drive/MyDrive/chexpert"
  train_csv: "CheXpert-v1.0-small/train.csv"
  valid_csv: "CheXpert-v1.0-small/valid.csv"
  label_set: ["Cardiomegaly", "Pleural Effusion", "Pneumothorax", "Consolidation", "Atelectasis", "Edema"]
  uncertain_policy: "zeros"
  view_policy: "frontal_only"
  image_size: 224
  num_workers: 2

split:
  labeled_ratio: 0.05
  seed: 42
  splits_dir: "/content/drive/MyDrive/outputs/splits"
  min_positive_per_class: 1

model:
  backbone: "resnet50_imagenet"
  pretrained_weights_path: null
  num_classes: 6
  dropout_rate: 0.5
  normalization_mean: [0.485, 0.456, 0.406]
  normalization_std: [0.229, 0.224, 0.225]

training:
  learning_rate: 0.0001
  batch_size: 32
  num_epochs: 30
  optimizer: "adam"
  weight_decay: 0.0001
  scheduler: "cosine"
  resume_checkpoint: null

pseudo_label:
  enabled: false
  confidence_thresholds: {}
  pseudo_label_policy: "positive_only"
  student_init: "from_scratch"
  student_pretrained_weights_path: null

uncertainty:
  enabled: false
  mc_dropout_passes: 20
  uncertainty_metric: "predictive_entropy"
  uncertainty_thresholds: {}

output_dir: "/content/drive/MyDrive/outputs"
optional_metrics: []
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Label column filtering preserves exactly the target set

*For any* CheXpert-like CSV DataFrame containing the 6 target label columns plus any number of extra columns, filtering to the Label_Set SHALL produce a DataFrame with exactly 6 columns matching the Label_Set, with no extra columns and no missing target columns.

**Validates: Requirements 1.1, 1.2**

### Property 2: Uncertain label mapping produces clean binary labels

*For any* label matrix with values in {-1, 0, 1} and any valid mapping policy ("zeros" or "ones"), applying the uncertain label mapping SHALL produce a matrix containing only values in {0, 1}, where every -1 entry is replaced according to the policy and all 0/1 entries are unchanged.

**Validates: Requirements 1.3**

### Property 3: Frontal-only view filtering retains only frontal images

*For any* set of image metadata entries with view types in {"Frontal", "Lateral"}, applying the frontal-only filter SHALL retain all and only entries with view type "Frontal", and the count of retained entries SHALL equal the count of frontal entries in the original set.

**Validates: Requirements 1A.2**

### Property 4: Split generation produces a valid partition

*For any* training dataset of size N and any labeled ratio r ∈ (0, 1), the generated split SHALL produce a Labeled_Subset and Unlabeled_Subset such that: (a) their union equals the full index set {0, ..., N-1}, (b) their intersection is empty, and (c) |Labeled_Subset| equals round(r × N).

**Validates: Requirements 2.1, 2.5**

### Property 5: Split generation is deterministic given the same seed

*For any* dataset size, labeled ratio, and random seed, generating a split twice with identical parameters SHALL produce identical Labeled_Subset and Unlabeled_Subset index lists.

**Validates: Requirements 2.2, 10.1, 10.2**

### Property 6: Split metadata round-trip persistence

*For any* valid split metadata object (containing labeled_ratio, seed, labeled_indices, unlabeled_indices, and per-class counts), saving it to disk as JSON and loading it back SHALL produce an object equal to the original.

**Validates: Requirements 2.3**

### Property 7: Stratified sampling preserves per-class prevalence

*For any* multi-label dataset and labeled ratio, the per-class positive prevalence in the Labeled_Subset SHALL be within a tolerance (e.g., ±5 percentage points) of the per-class positive prevalence in the full training set.

**Validates: Requirements 2.6**

### Property 8: Best checkpoint tracks the maximum validation AUROC

*For any* sequence of (epoch, validation_macro_auroc) pairs produced during training, the Best_Checkpoint SHALL correspond to the epoch with the highest validation_macro_auroc value. If multiple epochs tie, the latest one is selected.

**Validates: Requirements 3A.3**

### Property 9: Positive-only confidence thresholding accepts only high-confidence positives

*For any* probability matrix of shape (N, C) and per-class confidence threshold dict, the PositiveOnlyStrategy SHALL: (a) assign pseudo-label 1.0 for entries where probability > threshold, (b) assign NaN (not 0) for entries where probability ≤ threshold, and (c) apply thresholds independently per class (changing one class's threshold does not affect another class's assignments).

**Validates: Requirements 5.2, 5.3, 5.4**

### Property 10: Ground-truth labels are never overwritten by pseudo-labels

*For any* labeled dataset and any set of pseudo-labels, merging them into a CombinedDataset SHALL preserve the original ground-truth label vectors for all samples that belong to the Labeled_Subset. The label vector returned by `__getitem__` for a labeled sample SHALL be identical to the original.

**Validates: Requirements 5.7, 13.1**

### Property 11: Predictive entropy computation follows the binary entropy formula

*For any* MC Dropout probability tensor of shape (T, N, C) with values in (0, 1), the computed predictive entropy SHALL equal H = -[p·log(p) + (1-p)·log(1-p)] where p is the mean probability over the T passes, computed independently per sample and per class.

**Validates: Requirements 6.2**

### Property 12: Uncertainty-filtered thresholding requires both conditions

*For any* probability matrix, uncertainty matrix, confidence thresholds, and uncertainty thresholds, the UncertaintyFilteredStrategy SHALL accept a pseudo-label for entry (i, j) if and only if probability(i, j) > confidence_threshold(j) AND uncertainty(i, j) < uncertainty_threshold(j). Entries failing either condition SHALL be rejected.

**Validates: Requirements 6.3, 6.4**

### Property 13: Pseudo-label artifact round-trip persistence

*For any* pseudo-label artifact (containing sample indices, per-class probabilities, accepted pseudo-labels, rejection masks, and optional uncertainty values), saving it to disk and loading it back SHALL produce a DataFrame with identical values (within floating-point tolerance) for all fields.

**Validates: Requirements 6A.1, 6A.3**

### Property 14: AUROC computation matches reference implementation

*For any* binary ground-truth matrix and score matrix of shape (N, C) where each class has at least one positive and one negative sample, the computed macro_auroc SHALL equal `sklearn.metrics.roc_auc_score(y_true, y_score, average='macro')` within floating-point tolerance (1e-6).

**Validates: Requirements 7.1**

## Error Handling

### Data Loading Errors

| Error Condition | Handling | Requirement |
|---|---|---|
| Dataset path does not exist | Raise `FileNotFoundError` with path | Req 1.1 |
| CSV missing required label columns | Raise `ValueError` listing missing columns | Req 1.1 |
| Image file referenced in CSV not found | Log warning, skip sample, continue | Req 15A.1 |
| Unknown uncertain_policy value | Raise `ValueError` with valid options | Req 1.3 |
| Unknown view_policy value | Raise `ValueError` with valid options | Req 1A.1 |

### Split Generation Errors

| Error Condition | Handling | Requirement |
|---|---|---|
| Labeled ratio produces 0 samples | Raise `ValueError` | Req 2.1 |
| No positive samples for a class after split | Retry with offset seed (up to 10 retries) | Req 2.7 |
| All retries exhausted | Raise `SplitGenerationError` with class name and ratio | Req 2.8 |
| Split metadata file corrupted | Raise `ValueError`, suggest regeneration | Req 2.4 |

### Training Errors

| Error Condition | Handling | Requirement |
|---|---|---|
| Resume checkpoint path invalid | Raise `FileNotFoundError` | Req 12.4 |
| Resume checkpoint incompatible (different model) | Raise `RuntimeError` with mismatch details | Req 12.4 |
| NaN loss detected | Log error, save emergency checkpoint, raise `RuntimeError` | Req 3.2 |
| GPU OOM | Log batch size suggestion, raise `RuntimeError` | Req 12 |
| CUDA deterministic mode unavailable | Log warning, continue training | Req 10.5 |

### Pseudo-Labeling Errors

| Error Condition | Handling | Requirement |
|---|---|---|
| Teacher checkpoint not found | Raise `FileNotFoundError` | Req 5.1 |
| Zero pseudo-labels accepted for all classes | Log warning, continue with labeled-only data | Req 5.8 |
| MC Dropout passes ≤ 0 | Raise `ValueError` | Req 6.6 |
| Uncertainty metric not supported | Raise `ValueError` with supported options | Req 6.7 |

### Environment Errors

| Error Condition | Handling | Requirement |
|---|---|---|
| Git repository not detected | Log warning, set git_commit to None | Req 10A.2 |
| Google Drive not mounted (Colab) | Raise `FileNotFoundError` with mount instructions | Req 12.1 |
| Output directory not writable | Raise `PermissionError` | Req 14.1 |

## Testing Strategy

### Dual Testing Approach

This project uses both unit tests and property-based tests for comprehensive coverage.

**Property-Based Testing Library:** [Hypothesis](https://hypothesis.readthedocs.io/) for Python

**Configuration:**
- Minimum 100 iterations per property test (`@settings(max_examples=100)`)
- Each property test tagged with: `# Feature: semisup-multilabel-cxr, Property {N}: {title}`
- Deadline disabled for tests involving I/O: `@settings(deadline=None)`

### Property-Based Tests (14 properties)

Each correctness property from the design maps to a single Hypothesis test:

| Property | Module Under Test | Key Generators |
|---|---|---|
| P1: Label column filtering | `data/chexpert_dataset.py` | Random DataFrames with varying column sets |
| P2: Uncertain label mapping | `data/chexpert_dataset.py` | Random (N,6) matrices with {-1,0,1} values |
| P3: View filtering | `data/chexpert_dataset.py` | Random image metadata with mixed views |
| P4: Split partition validity | `data/split_generator.py` | Random (N, ratio, seed) tuples |
| P5: Split determinism | `data/split_generator.py` | Random (N, ratio, seed) tuples |
| P6: Split metadata round-trip | `data/split_generator.py` | Random split metadata dicts |
| P7: Stratified prevalence | `data/split_generator.py` | Random multi-label matrices + ratios |
| P8: Best checkpoint selection | `training/trainer.py` | Random AUROC sequences |
| P9: Confidence thresholding | `pseudo_labeling/threshold_strategy.py` | Random (N,C) prob matrices + threshold dicts |
| P10: Label integrity | `data/combined_dataset.py` | Random labeled + pseudo-labeled data |
| P11: Predictive entropy | `pseudo_labeling/mc_dropout.py` | Random (T,N,C) probability tensors |
| P12: Uncertainty filtering | `pseudo_labeling/threshold_strategy.py` | Random probs + uncertainties + thresholds |
| P13: Artifact round-trip | `pseudo_labeling/artifact_io.py` | Random pseudo-label DataFrames |
| P14: AUROC computation | `evaluation/metrics.py` | Random (y_true, y_score) matrices |

### Unit Tests (Example-Based)

| Area | Tests | Requirements |
|---|---|---|
| Config loading | Load each of 4 template YAMLs, verify all fields parsed | Req 9.1, 9.2 |
| Config validation | Missing required fields rejected; pseudo-label config requires thresholds | Req 9.3, 9.4 |
| View policy default | Default config uses frontal_only | Req 1A.5 |
| Split caching | Existing split file is loaded, not regenerated | Req 2.4 |
| Checkpoint format | Both best + last checkpoints saved with correct metadata | Req 3A.2, 3A.5 |
| Backbone factory | ImageNet and LVM-Med backbones created correctly | Req 11.3 |
| Strategy selection | Config selects correct ThresholdStrategy subclass | Req 11.2 |
| Pseudo-label logging | Per-class accepted/rejected counts logged | Req 5.8, 6.5 |
| Git hash recording | Commit hash captured when in git repo; warning when not | Req 10A.1, 10A.2 |
| Resume from checkpoint | Training resumes from correct epoch with correct state | Req 12.4 |

### Integration Tests

| Area | Tests | Requirements |
|---|---|---|
| End-to-end supervised | Train 2 epochs on tiny dataset, verify checkpoint + metrics | Req 3, 3A |
| End-to-end pseudo-label | Teacher train → inference → threshold → student train | Req 5 |
| End-to-end uncertainty | Teacher train → MC Dropout → filter → student train | Req 6 |
| Evaluation standalone | Load checkpoint, run evaluation, verify results CSV | Req 7, 11.4 |
| Sanity checks | Run all 4 sanity check functions on valid data | Req 15A |

### Sanity Checks (Component Validation)

Per Requirement 15A, each implementation stage includes a lightweight validation:

1. **Data loading**: Verify image accessibility (sample 5 images), label shape == (6,), train/val non-empty
2. **Split generation**: Verify disjointness, size match, per-class positive counts > 0
3. **Training loop**: Single batch forward pass succeeds, loss is finite, gradients are non-zero
4. **Evaluation**: Macro AUROC and per-class AUROC computable on 50-sample subset

### Test Execution

```bash
# Run all tests
pytest tests/ -v

# Run only property tests
pytest tests/ -v -k "property"

# Run only unit tests
pytest tests/ -v -k "not property and not integration"

# Run sanity checks
python -m scripts.sanity_check --config configs/supervised_baseline.yaml
```
