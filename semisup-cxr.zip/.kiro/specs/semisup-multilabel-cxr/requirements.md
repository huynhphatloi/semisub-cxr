# Requirements Document

## Introduction

This document specifies the requirements for a Phase 1 course project: a systematic empirical study of low-label multi-label chest X-ray (CXR) classification. The project investigates whether medical-domain pretrained backbones, class-wise pseudo-labeling, and uncertainty-aware filtering improve multi-label CXR classification when labeled data are scarce. The study uses the CheXpert dataset restricted to 6 pathology labels and evaluates 4 experimental settings across 3 low-label ratios (5%, 10%, 20%).

Phase 1 is scoped as a reproducible, master's-level course project. The codebase must be modular and extensible so that Phase 2 (thesis/paper-level extensions including PAUPL, asymmetric thresholding, pathology co-occurrence, and external validation) can build on it without architectural rewrites. Phase 2 features are explicitly out of scope for implementation.

## Glossary

- **CheXpert**: A large-scale chest X-ray dataset from Stanford containing frontal and lateral radiographs with automated labels for 14 pathology observations.
- **CXR**: Chest X-ray radiograph image.
- **Label_Set**: The fixed set of 6 pathology labels used in this project: Cardiomegaly, Pleural Effusion, Pneumothorax, Consolidation, Atelectasis, Edema.
- **Labeled_Subset**: The fraction of training samples with ground-truth labels available for supervised training, determined by the Labeled_Ratio.
- **Unlabeled_Subset**: The remaining training samples after the Labeled_Subset is drawn; these samples have their labels withheld during training.
- **Labeled_Ratio**: The fraction of training data used as labeled data; one of {0.05, 0.10, 0.20}.
- **Split_Metadata**: A persistent record (e.g., JSON or CSV) that maps each training sample to its labeled or unlabeled assignment for a given Labeled_Ratio and random seed.
- **Supervised_Baseline**: Experimental setting 1 — a classifier fine-tuned from an ImageNet-pretrained backbone using only the Labeled_Subset.
- **LVM_Med_Finetuning**: Experimental setting 2 — a classifier fine-tuned from the LVM-Med pretrained backbone using only the Labeled_Subset.
- **LVM_Med**: A medical-domain vision model pretrained on diverse medical imaging datasets, providing a domain-specific feature extractor.
- **Pseudo_Labeling**: A semi-supervised technique where a trained teacher model generates predicted labels (pseudo-labels) for the Unlabeled_Subset, which are then used alongside real labels for retraining.
- **Class_Wise_Pseudo_Labeling**: Experimental setting 3 — Pseudo_Labeling applied independently per pathology class, using per-class confidence thresholds, on top of LVM_Med_Finetuning.
- **Uncertainty_Filtering**: Experimental setting 4 — Class_Wise_Pseudo_Labeling augmented with MC_Dropout-based uncertainty estimates to filter out unreliable pseudo-labels before retraining.
- **MC_Dropout**: Monte Carlo Dropout — a practical uncertainty approximation method where multiple stochastic forward passes with dropout enabled at inference time produce a distribution of predictions, from which uncertainty is estimated.
- **Macro_AUROC**: Area Under the Receiver Operating Characteristic curve averaged equally across all classes in the Label_Set.
- **Per_Class_AUROC**: AUROC computed independently for each class in the Label_Set.
- **Macro_F1**: F1 score averaged equally across all classes in the Label_Set (optional metric).
- **mAP**: Mean Average Precision across all classes in the Label_Set (optional metric).
- **Experiment_Config**: A YAML configuration file that fully specifies all hyperparameters, paths, seeds, and settings for a single experiment run.
- **Pipeline**: The end-to-end system encompassing data loading, training, pseudo-labeling, evaluation, and reporting.
- **Checkpoint**: A serialized snapshot of model weights, optimizer state, and training metadata saved during or after training.
- **Training_Loop**: The iterative process of forward pass, loss computation, backpropagation, and parameter update over batches of data.
- **Frontal_Only_View**: A dataset filtering policy in which only frontal chest X-ray views (e.g., AP/PA) are retained and lateral views are excluded from all experiments.
- **Best_Checkpoint**: The checkpoint corresponding to the epoch with the highest validation Macro_AUROC.
- **Last_Checkpoint**: The checkpoint saved at the end of the final training epoch, regardless of validation performance.
- **Predictive_Entropy**: An uncertainty measure computed from the mean predictive probability over MC_Dropout forward passes, used as the default uncertainty metric in this project.
- **Pseudo_Positive_Label**: A pseudo-label with value 1 accepted for a class when the model's predicted probability exceeds a configured confidence threshold.
- **Pseudo_Negative_Label**: A pseudo-label with value 0 accepted for a class when the model's predicted probability falls below a configured negative confidence threshold, if negative pseudo-labeling is enabled.
- **Colab_Environment**: Google Colab notebook execution environment with Google Drive integration for persistent storage.

## Requirements

### Requirement 1: CheXpert Data Loading

**User Story:** As a researcher, I want to load the CheXpert dataset and restrict it to 6 target pathology labels, so that I can focus the study on a well-defined multi-label classification task.

#### Acceptance Criteria

1. WHEN the CheXpert dataset path is provided, THE Pipeline SHALL load the dataset and retain only the 6 labels in the Label_Set (Cardiomegaly, Pleural Effusion, Pneumothorax, Consolidation, Atelectasis, Edema).
2. WHEN the dataset is loaded, THE Pipeline SHALL discard all pathology columns not in the Label_Set from the label matrix.
3. WHEN the dataset contains missing or uncertain label entries (e.g., -1 values in CheXpert), THE Pipeline SHALL apply a configurable mapping strategy (e.g., U-Zeros, U-Ones) specified in the Experiment_Config.
4. THE Pipeline SHALL expose the loaded dataset as separate training and validation splits consistent with the official CheXpert train/valid partition.

### Requirement 1A: View Filtering Policy

**User Story:** As a researcher, I want to control which image views are used in the study, so that all experiments are conducted on a consistent and comparable subset of CheXpert.

#### Acceptance Criteria

1. WHEN the dataset is loaded, THE Pipeline SHALL support a configurable view policy specified in the Experiment_Config.
2. WHEN the Frontal_Only_View policy is enabled, THE Pipeline SHALL retain only frontal chest X-ray images and exclude lateral views from all experiments.
3. THE Pipeline SHALL use the same view policy across all 4 experimental settings and all 3 Labeled_Ratios.
4. THE Pipeline SHALL record the selected view policy in the Experiment_Config and experiment logs.
5. THE default Phase 1 configuration SHALL use Frontal_Only_View.

### Requirement 2: Low-Label Split Generation

**User Story:** As a researcher, I want to generate reproducible low-label splits at 5%, 10%, and 20% labeled ratios, so that I can systematically study the effect of label scarcity.

#### Acceptance Criteria

1. WHEN a Labeled_Ratio and a random seed are provided, THE Pipeline SHALL partition the training set into a Labeled_Subset and an Unlabeled_Subset such that the Labeled_Subset contains exactly the specified fraction of training samples.
2. THE Pipeline SHALL use the provided random seed to ensure that identical Labeled_Ratio and seed values always produce identical Labeled_Subset and Unlabeled_Subset assignments.
3. WHEN a split is generated, THE Pipeline SHALL persist the Split_Metadata to disk as a file (JSON or CSV) recording the assignment of every training sample.
4. WHEN Split_Metadata already exists for a given Labeled_Ratio and seed, THE Pipeline SHALL load the existing split rather than regenerating it.
5. THE Pipeline SHALL ensure that the Labeled_Subset and Unlabeled_Subset are mutually exclusive and collectively exhaustive over the training set.
6. THE Pipeline SHALL attempt to preserve class-wise positive prevalence in the Labeled_Subset using a stratified or iterative stratified sampling strategy where feasible for multi-label data.
7. IF a generated Labeled_Subset contains no positive samples for one or more classes in the Label_Set, THEN THE Pipeline SHALL attempt to regenerate the split using a different random draw or resampling procedure.
8. IF repeated split generation still fails to include at least one positive sample for a class, THEN THE Pipeline SHALL raise an error with a descriptive message identifying the affected class and the Labeled_Ratio.

### Requirement 3: Supervised Baseline Training

**User Story:** As a researcher, I want to train a supervised multi-label classifier from an ImageNet-pretrained backbone on the Labeled_Subset only, so that I can establish a standard pretrained baseline for comparison.

#### Acceptance Criteria

1. WHEN the Supervised_Baseline experiment is configured, THE Training_Loop SHALL initialize the backbone from ImageNet-pretrained weights and train using only the Labeled_Subset.
2. THE Training_Loop SHALL use binary cross-entropy loss computed independently for each of the 6 labels in the Label_Set.
3. WHEN training completes, THE Pipeline SHALL save a Checkpoint containing model weights, optimizer state, epoch number, and the Experiment_Config used.
4. THE Training_Loop SHALL log training loss and validation Macro_AUROC at the end of each epoch.
5. THE Training_Loop SHALL NOT access any samples from the Unlabeled_Subset during Supervised_Baseline training.

### Requirement 3A: Model Selection and Checkpoint Policy

**User Story:** As a researcher, I want a clear and consistent model selection policy, so that all experiments use the same validation-based checkpointing logic.

#### Acceptance Criteria

1. THE Pipeline SHALL evaluate validation Macro_AUROC at the end of each training epoch.
2. THE Pipeline SHALL save both a Best_Checkpoint and a Last_Checkpoint for every training run.
3. THE Best_Checkpoint SHALL be selected based on the highest validation Macro_AUROC achieved during training.
4. THE Last_Checkpoint SHALL correspond to the final epoch of training regardless of validation performance.
5. THE Pipeline SHALL record the epoch number and validation Macro_AUROC associated with the Best_Checkpoint.
6. THE same model selection policy SHALL be applied consistently across all 4 experimental settings.

### Requirement 4: LVM-Med Fine-Tuning

**User Story:** As a researcher, I want to fine-tune a classifier from the LVM-Med pretrained backbone on the Labeled_Subset, so that I can evaluate whether medical-domain pretraining improves low-label CXR classification.

#### Acceptance Criteria

1. WHEN the LVM_Med_Finetuning experiment is configured, THE Training_Loop SHALL initialize the backbone from LVM_Med pretrained weights and train using only the Labeled_Subset.
2. THE Training_Loop SHALL use the same loss function, optimizer configuration, and training schedule as the Supervised_Baseline, except for the backbone initialization.
3. WHEN training completes, THE Pipeline SHALL save a Checkpoint following the same format as the Supervised_Baseline Checkpoint.
4. THE Training_Loop SHALL log training loss and validation Macro_AUROC at the end of each epoch.
5. THE Training_Loop SHALL NOT access any samples from the Unlabeled_Subset during LVM_Med_Finetuning training.

### Requirement 5: Class-Wise Pseudo-Labeling

**User Story:** As a researcher, I want to apply class-wise pseudo-labeling on top of the LVM-Med fine-tuned model, so that I can evaluate whether leveraging unlabeled data with per-class thresholds improves multi-label CXR classification.

#### Acceptance Criteria

1. WHEN the Class_Wise_Pseudo_Labeling experiment is configured, THE Pipeline SHALL first train a teacher model using the LVM_Med_Finetuning procedure on the Labeled_Subset.
2. WHEN the teacher model is trained, THE Pipeline SHALL generate pseudo-labels for each sample in the Unlabeled_Subset by applying the teacher model and using independent per-class confidence thresholds.
3. THE Pipeline SHALL apply confidence thresholds independently for each of the 6 labels in the Label_Set, accepting a Pseudo_Positive_Label for a given class only when the teacher model's predicted probability exceeds the configured threshold for that class.
4. IF the confidence threshold is not satisfied for a given class, THEN THE Pipeline SHALL assign no pseudo-label for that class rather than forcing a negative label.
5. WHEN pseudo-labels are generated, THE Pipeline SHALL retrain a student model from the configured pretrained backbone initialization rather than warm-started from the teacher weights, unless an alternative strategy is explicitly enabled in the Experiment_Config.
6. THE Pipeline SHALL retrain the student model using the combined Labeled_Subset (with ground-truth labels) and the accepted pseudo-labeled samples.
7. THE Pipeline SHALL ensure that ground-truth labels from the Labeled_Subset are never overwritten or replaced by pseudo-labels.
8. THE Pipeline SHALL log the number of accepted pseudo-labels per class after thresholding.
9. THE default Phase 1 pseudo-labeling policy SHALL use positive-only pseudo-label acceptance unless explicitly overridden in the Experiment_Config.

### Requirement 6: Uncertainty-Aware Filtering

**User Story:** As a researcher, I want to add MC Dropout-based uncertainty filtering to the pseudo-labeling workflow, so that I can evaluate whether filtering unreliable pseudo-labels improves training stability and performance.

#### Acceptance Criteria

1. WHEN the Uncertainty_Filtering experiment is configured, THE Pipeline SHALL perform multiple stochastic forward passes (MC_Dropout) through the teacher model for each sample in the Unlabeled_Subset, with dropout enabled at inference time.
2. THE Pipeline SHALL compute a per-class uncertainty estimate (e.g., predictive entropy or variance of predicted probabilities) from the MC_Dropout forward passes for each sample.
3. WHEN pseudo-labels are generated, THE Pipeline SHALL reject a pseudo-label for a given class if the corresponding per-class uncertainty estimate exceeds a configurable uncertainty threshold.
4. THE Pipeline SHALL apply uncertainty filtering in addition to the confidence thresholding from Class_Wise_Pseudo_Labeling, such that a pseudo-label is accepted only when both the confidence threshold and the uncertainty threshold are satisfied.
5. THE Pipeline SHALL log the number of pseudo-labels rejected by uncertainty filtering per class, separately from those rejected by confidence thresholding.
6. THE Pipeline SHALL use a configurable number of MC_Dropout forward passes specified in the Experiment_Config.
7. THE default per-class uncertainty metric SHALL be Predictive_Entropy computed from the mean class probabilities over MC_Dropout forward passes, unless another supported metric is explicitly specified in the Experiment_Config.
8. THE Pipeline SHALL record the uncertainty metric used in the experiment logs and saved configuration.

### Requirement 6A: Pseudo-Label Artifact Persistence

**User Story:** As a researcher, I want to save pseudo-label generation artifacts, so that I can inspect, debug, and analyze the pseudo-labeling behavior of the system.

#### Acceptance Criteria

1. WHEN pseudo-labels are generated for the Unlabeled_Subset, THE Pipeline SHALL save a structured artifact file containing, at minimum: sample identifier, per-class predicted probabilities, accepted pseudo-labels, rejection status, and uncertainty values if uncertainty filtering is enabled.
2. THE Pipeline SHALL save pseudo-label artifacts separately for each experimental run, organized by experimental setting, Labeled_Ratio, and seed.
3. THE Pipeline SHALL allow pseudo-label artifacts to be loaded later for analysis without rerunning pseudo-label generation.

### Requirement 7: Evaluation and Metrics

**User Story:** As a researcher, I want to compute Macro AUROC and per-class AUROC for every experiment, so that I can systematically compare the 4 experimental settings across all label ratios.

#### Acceptance Criteria

1. WHEN a trained model and the validation set are provided, THE Pipeline SHALL compute Macro_AUROC and Per_Class_AUROC on the official CheXpert validation split.
2. THE Pipeline SHALL compute evaluation metrics for all 4 experimental settings (Supervised_Baseline, LVM_Med_Finetuning, Class_Wise_Pseudo_Labeling, Uncertainty_Filtering) across all 3 Labeled_Ratios (5%, 10%, 20%).
3. THE Pipeline SHALL store all evaluation results in a structured format (e.g., CSV or JSON) that records the experimental setting, Labeled_Ratio, Macro_AUROC, and Per_Class_AUROC for each of the 6 labels.
4. WHERE the optional metrics are enabled in the Experiment_Config, THE Pipeline SHALL additionally compute Macro_F1 and mAP.
5. THE Pipeline SHALL produce a summary comparison table of Macro_AUROC across all 4 settings and 3 Labeled_Ratios.

### Requirement 8: Results Visualization and Reporting

**User Story:** As a researcher, I want to generate publication-quality plots and structured result tables, so that I can include them directly in the course-project report.

#### Acceptance Criteria

1. WHEN evaluation results are available, THE Pipeline SHALL generate a bar chart or grouped plot comparing Macro_AUROC across the 4 experimental settings for each Labeled_Ratio.
2. WHEN evaluation results are available, THE Pipeline SHALL generate per-class AUROC comparison plots across the 4 experimental settings.
3. THE Pipeline SHALL save all generated plots as image files (PNG or PDF) in a configurable output directory.
4. THE Pipeline SHALL generate a LaTeX-formatted or Markdown-formatted results table summarizing Macro_AUROC and Per_Class_AUROC across all settings and Labeled_Ratios.

### Requirement 9: YAML Config-Driven Experiment Management

**User Story:** As a researcher, I want every experiment to be fully specified by a YAML configuration file, so that I can reproduce any experiment by rerunning with the same config.

#### Acceptance Criteria

1. THE Pipeline SHALL accept a single YAML Experiment_Config file as the entry point for any training, pseudo-labeling, or evaluation run.
2. THE Experiment_Config SHALL specify at minimum: experiment name, experimental setting, backbone type, pretrained weights path, Labeled_Ratio, random seed, learning rate, batch size, number of epochs, output directory, and dataset paths.
3. WHEN the Class_Wise_Pseudo_Labeling or Uncertainty_Filtering setting is configured, THE Experiment_Config SHALL additionally specify per-class confidence thresholds.
4. WHEN the Uncertainty_Filtering setting is configured, THE Experiment_Config SHALL additionally specify the number of MC_Dropout forward passes and the per-class uncertainty thresholds.
5. THE Pipeline SHALL save a copy of the Experiment_Config used alongside every Checkpoint and evaluation result output.
6. THE Pipeline SHALL provide separate default config templates for each of the 4 experimental settings.

### Requirement 10: Reproducibility Guarantees

**User Story:** As a researcher, I want all experiments to be fully reproducible given the same config and code version, so that results can be independently verified.

#### Acceptance Criteria

1. THE Pipeline SHALL set random seeds for Python, NumPy, and PyTorch (including CUDA) at the start of every run using the seed specified in the Experiment_Config.
2. THE Pipeline SHALL use deterministic data splits loaded from or persisted to Split_Metadata files.
3. WHEN a Checkpoint is saved, THE Pipeline SHALL include the random seed, Experiment_Config, and the current library versions (PyTorch, NumPy, Python) in the Checkpoint metadata.
4. THE Pipeline SHALL log all hyperparameters at the start of each run to a persistent log file or structured record.
5. IF the Pipeline detects that PyTorch CUDA deterministic mode is unavailable, THEN THE Pipeline SHALL log a warning indicating that exact GPU reproducibility cannot be guaranteed.

### Requirement 10A: Code Version Tracking

**User Story:** As a researcher, I want experiment outputs to record the exact code version used, so that results can be traced back to a specific implementation state.

#### Acceptance Criteria

1. WHEN the Pipeline is executed inside a Git repository, THE Pipeline SHALL record the current Git commit hash in the experiment metadata, logs, and Checkpoint metadata.
2. IF no Git repository is detected, THEN THE Pipeline SHALL log a warning indicating that code-version tracking is unavailable.
3. THE recorded Git commit hash SHALL be saved alongside the Experiment_Config and evaluation outputs.

### Requirement 11: Modular Project Architecture

**User Story:** As a researcher, I want a clean modular codebase with well-separated responsibilities, so that Phase 2 extensions (PAUPL, asymmetric thresholding, pathology co-occurrence, external validation) can be added without architectural rewrites.

#### Acceptance Criteria

1. THE Pipeline SHALL organize code into separate modules for: data loading and splitting, model definition, training loops, pseudo-labeling logic, uncertainty estimation, evaluation, configuration parsing, and utility functions.
2. THE Pipeline SHALL define the pseudo-labeling interface such that the thresholding strategy (confidence-only vs. confidence-plus-uncertainty) is selected by configuration, not by code branching in the training loop.
3. THE Pipeline SHALL define the backbone initialization as a configurable factory so that new backbone types can be added by registering a new loader without modifying existing training code.
4. THE Pipeline SHALL define the evaluation module independently from the training module so that evaluation can be run standalone on any saved Checkpoint.
5. THE Pipeline SHALL keep all file paths, hyperparameters, and experiment-specific constants in the Experiment_Config rather than hard-coded in source files.

### Requirement 12: Google Colab Execution Support

**User Story:** As a researcher, I want to run the entire pipeline in Google Colab with Google Drive integration, so that I can execute experiments without local GPU infrastructure.

#### Acceptance Criteria

1. THE Pipeline SHALL provide a Colab-compatible entry point (notebook or script) that mounts Google Drive and sets up the project directory structure.
2. WHEN running in the Colab_Environment, THE Pipeline SHALL read datasets, configs, and pretrained weights from configurable Google Drive paths.
3. WHEN running in the Colab_Environment, THE Pipeline SHALL save all Checkpoints, logs, evaluation results, and plots to a configurable Google Drive output directory.
4. WHEN a Colab session is interrupted and restarted, THE Pipeline SHALL support explicit resume from a user-specified Checkpoint path provided in the Experiment_Config or command-line arguments.
5. THE Pipeline MAY optionally support automatic detection of resumable Checkpoints, but automatic resume SHALL NOT be required for Phase 1.
6. THE Pipeline SHALL function identically whether executed in the Colab_Environment or a local environment, differing only in the configured paths.

### Requirement 13: Label Leakage Prevention

**User Story:** As a researcher, I want the pipeline to enforce strict separation between labeled and unlabeled data, so that no label information leaks into the unlabeled pathway and experimental comparisons remain fair.

#### Acceptance Criteria

1. THE Pipeline SHALL ensure that ground-truth labels for samples in the Unlabeled_Subset are never accessible to the Training_Loop or the pseudo-labeling module during training.
2. WHEN generating pseudo-labels, THE Pipeline SHALL use only the teacher model's predictions and SHALL NOT reference ground-truth labels for the Unlabeled_Subset.
3. THE Pipeline SHALL use identical image resolution and augmentation policy across all 4 experimental settings to ensure fair comparison.
4. THE Pipeline MAY use backbone-specific normalization parameters where required, provided these are explicitly recorded in the Experiment_Config and applied consistently for all runs using the same backbone.
5. THE Pipeline SHALL use the same validation set (official CheXpert validation split) for evaluation across all experimental settings and Labeled_Ratios.

### Requirement 14: Checkpoint and Logging Management

**User Story:** As a researcher, I want organized checkpoint and log storage with clear naming conventions, so that I can track and compare experiments across multiple runs.

#### Acceptance Criteria

1. THE Pipeline SHALL save Checkpoints in a directory structure organized by experimental setting, Labeled_Ratio, and random seed.
2. THE Pipeline SHALL name Checkpoint files using a convention that includes the experimental setting, Labeled_Ratio, seed, and epoch number.
3. THE Pipeline SHALL maintain a training log file per experiment run that records epoch-level metrics, timestamps, and the Experiment_Config used.
4. WHEN an experiment run completes, THE Pipeline SHALL save a final summary record containing the best validation Macro_AUROC, the corresponding epoch, and all Per_Class_AUROC values.

### Requirement 15: Implementation Ordering

**User Story:** As a researcher, I want a strict implementation order for the pipeline components, so that each component can be validated before building the next.

#### Acceptance Criteria

1. THE Pipeline SHALL be implemented in the following strict order: (a) data loading and split generation, (b) Supervised_Baseline training, (c) LVM_Med_Finetuning training, (d) Class_Wise_Pseudo_Labeling, (e) Uncertainty_Filtering, (f) evaluation and reporting.
2. WHEN a component is implemented, THE Pipeline SHALL include a validation step (e.g., a smoke test or unit check) that confirms the component functions correctly before proceeding to the next component.
3. THE Pipeline SHALL ensure that each later component depends only on interfaces defined by earlier components, not on implementation details.

### Requirement 15A: Component Sanity Checks

**User Story:** As a researcher, I want lightweight sanity checks after each implementation stage, so that failures are caught early before more complex components are added.

#### Acceptance Criteria

1. AFTER data loading is implemented, THE Pipeline SHALL verify: image file accessibility, label dimensionality equals 6, and non-empty training and validation sets.
2. AFTER split generation is implemented, THE Pipeline SHALL verify: labeled and unlabeled subsets are disjoint, subset sizes match the configured Labeled_Ratio, and per-class positive counts in the Labeled_Subset are valid.
3. AFTER a training loop is implemented, THE Pipeline SHALL verify: a single batch forward pass succeeds, loss can be computed, gradients can be backpropagated, and a mini-epoch completes without runtime errors.
4. AFTER evaluation is implemented, THE Pipeline SHALL verify that Macro_AUROC and Per_Class_AUROC can be computed successfully on a small validation subset.

### Requirement 16: Phase 2 Extensibility

**User Story:** As a researcher, I want the Phase 1 codebase to be structured for clean extension to Phase 2 features, so that I can add PAUPL, asymmetric thresholding, pathology co-occurrence, and external validation without rewriting the core pipeline.

#### Acceptance Criteria

1. THE Pipeline SHALL define the pseudo-label acceptance logic as a pluggable strategy (e.g., a base class or callable interface) so that asymmetric positive/negative thresholding can be added as a new strategy in Phase 2.
2. THE Pipeline SHALL define the backbone factory to accept new backbone identifiers so that chest-specific foundation models can be registered in Phase 2 without modifying existing code.
3. THE Pipeline SHALL define the dataset loading interface to accept dataset identifiers so that MIMIC-CXR-JPG can be added as an external validation dataset in Phase 2 without modifying the evaluation module.
4. THE Pipeline SHALL structure the pseudo-labeling module such that a pathology co-occurrence consistency check can be inserted as an additional filtering step in Phase 2.
5. THE Pipeline SHALL NOT implement any Phase 2 features (PAUPL, asymmetric thresholding, pathology co-occurrence module, MIMIC-CXR-JPG loading, or multi-round self-training) in the Phase 1 codebase.
