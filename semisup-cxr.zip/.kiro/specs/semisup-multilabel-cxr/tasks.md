# Implementation Plan: Semi-Supervised Multi-Label CXR Classification

## Overview

This plan implements a modular Python pipeline for low-label multi-label chest X-ray classification using CheXpert. Implementation follows the strict ordering from Requirement 15: data loading → supervised baseline → LVM-Med fine-tuning → pseudo-labeling → uncertainty filtering → evaluation/reporting. Each stage is validated before proceeding to the next. Property-based tests (Hypothesis) are placed alongside the modules they validate.

## Tasks

- [x] 1. Project scaffolding, utilities, and configuration system
  - [x] 1.1 Create project directory structure and `requirements.txt`
    - Create all directories: `src/`, `src/data/`, `src/models/`, `src/training/`, `src/pseudo_labeling/`, `src/evaluation/`, `src/utils/`, `configs/`, `scripts/`, `notebooks/`, `tests/`
    - Create all `__init__.py` files for each package
    - Write `requirements.txt` with: torch, torchvision, numpy, pandas, scikit-learn, matplotlib, seaborn, pyyaml, dacite, hypothesis, pytest, iterative-stratification, tqdm
    - _Requirements: 11.1_

  - [x] 1.2 Implement `src/utils/seed.py`
    - Implement `set_all_seeds(seed)` setting Python, NumPy, PyTorch, and CUDA seeds
    - Log warning if CUDA deterministic mode is unavailable
    - _Requirements: 10.1, 10.5_

  - [x] 1.3 Implement `src/utils/logging_utils.py`
    - Implement `setup_logging(output_dir, experiment_name)` returning a configured `logging.Logger`
    - Implement `get_git_commit()` returning the current git hash or None with a warning
    - Implement `log_library_versions()` returning a dict of torch, numpy, python versions
    - _Requirements: 10.4, 10A.1, 10A.2_

  - [x] 1.4 Implement `src/utils/checkpoint.py`
    - Implement `save_checkpoint(path, model, optimizer, epoch, config, val_metrics, extra_meta)` saving model state, optimizer state, epoch, config, val_metrics, seed, git_commit, library_versions
    - Implement `load_checkpoint(path, model, optimizer, device)` restoring state and returning metadata dict
    - _Requirements: 3.3, 10.3, 14.1, 14.2_

  - [x] 1.5 Implement `src/config.py`
    - Define all config dataclasses: `DataConfig`, `SplitConfig`, `ModelConfig`, `TrainingConfig`, `PseudoLabelConfig`, `UncertaintyConfig`, `ExperimentConfig`
    - Implement `load_config(yaml_path) -> ExperimentConfig` using PyYAML + dacite
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 11.5_

  - [x] 1.6 Create 4 YAML config templates in `configs/`
    - `supervised_baseline.yaml` — ImageNet backbone, pseudo_label disabled, uncertainty disabled
    - `lvmmed_finetune.yaml` — LVM-Med backbone with weights path placeholder
    - `pseudo_label.yaml` — LVM-Med backbone, pseudo_label enabled with per-class thresholds
    - `uncertainty_filter.yaml` — LVM-Med backbone, pseudo_label + uncertainty enabled
    - _Requirements: 9.5, 9.6_

  - [x] 1.7 Write unit tests for config loading
    - Test loading each of the 4 YAML templates and verify all fields are parsed correctly
    - Test that missing required fields raise errors
    - Test that pseudo-label config requires thresholds when enabled
    - _Requirements: 9.1, 9.2, 9.3, 9.4_

- [x] 2. Data loading and CheXpert dataset
  - [x] 2.1 Implement `src/data/chexpert_dataset.py`
    - Implement `CheXpertDataset(torch.utils.data.Dataset)` with constructor accepting `csv_path, image_root, label_set, uncertain_policy, view_policy, transform`
    - Load CSV, filter to `label_set` columns, apply uncertain_policy mapping (-1 → 0 or 1), filter views per view_policy
    - `__getitem__` returns `(image_tensor, label_vector, sample_index)` with label_vector as `FloatTensor(6,)`
    - Raise `FileNotFoundError` if dataset path missing, `ValueError` if label columns missing or unknown policy
    - Log warning and skip samples with missing image files
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1A.1, 1A.2, 1A.5_

  - [x] 2.2 Implement `src/data/transforms.py`
    - Implement `get_train_transform(model_config)` — Resize → RandomHorizontalFlip → RandomRotation(±10°) → ToTensor → Normalize
    - Implement `get_eval_transform(model_config)` — Resize → ToTensor → Normalize
    - Normalization params sourced from `ModelConfig` (backbone-specific)
    - _Requirements: 13.3, 13.4_

  - [x] 2.3 Write property test: P1 — Label column filtering preserves exactly the target set
    - **Property 1: Label column filtering preserves exactly the target set**
    - Generate random DataFrames with the 6 target columns plus extra columns; verify filtering retains exactly the 6 target columns
    - **Validates: Requirements 1.1, 1.2**

  - [x] 2.4 Write property test: P2 — Uncertain label mapping produces clean binary labels
    - **Property 2: Uncertain label mapping produces clean binary labels**
    - Generate random (N,6) matrices with values in {-1, 0, 1}; verify mapping produces only {0, 1} values with correct policy application
    - **Validates: Requirements 1.3**

  - [x] 2.5 Write property test: P3 — Frontal-only view filtering retains only frontal images
    - **Property 3: Frontal-only view filtering retains only frontal images**
    - Generate random metadata with mixed "Frontal"/"Lateral" views; verify filter retains all and only frontal entries
    - **Validates: Requirements 1A.2**

- [x] 3. Split generation
  - [x] 3.1 Implement `src/data/split_generator.py`
    - Implement `SplitGenerator` with `generate_split(dataset, labeled_ratio, seed, splits_dir) -> SplitMetadata`
    - Use `iterstrat.ml_stratifiers.MultilabelStratifiedShuffleSplit` for iterative stratified sampling
    - Persist split as JSON with: seed, labeled_ratio, total_train_size, labeled_size, unlabeled_size, labeled_indices, unlabeled_indices, per_class_positive_counts, generation_timestamp
    - Load existing split if file exists for given ratio/seed; validate on load
    - Validate minimum positive count per class; retry with offset seed (up to 10 retries); raise `SplitGenerationError` after max retries
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8_

  - [x] 3.2 Write property test: P4 — Split generation produces a valid partition
    - **Property 4: Split generation produces a valid partition**
    - Generate random (N, ratio, seed) tuples; verify union = full index set, intersection = empty, |Labeled| = round(r × N)
    - **Validates: Requirements 2.1, 2.5**

  - [x] 3.3 Write property test: P5 — Split generation is deterministic given the same seed
    - **Property 5: Split generation is deterministic given the same seed**
    - Generate random (N, ratio, seed); run split twice; verify identical index lists
    - **Validates: Requirements 2.2, 10.1, 10.2**

  - [x] 3.4 Write property test: P6 — Split metadata round-trip persistence
    - **Property 6: Split metadata round-trip persistence**
    - Generate random split metadata dicts; save to JSON and load back; verify equality
    - **Validates: Requirements 2.3**

  - [x] 3.5 Write property test: P7 — Stratified sampling preserves per-class prevalence
    - **Property 7: Stratified sampling preserves per-class prevalence**
    - Generate random multi-label matrices + ratios; verify per-class prevalence within ±5pp tolerance
    - **Validates: Requirements 2.6**

- [x] 4. Implement `src/utils/sanity_checks.py` and `scripts/generate_splits.py`
  - [x] 4.1 Implement `src/utils/sanity_checks.py`
    - Implement `check_data_loading(dataset)` — verify image accessibility (sample 5 images), label shape == (6,), non-empty
    - Implement `check_split_validity(split_meta, dataset_size, labeled_ratio)` — verify disjointness, size match, per-class positives > 0
    - Implement `check_training_step(model, sample_batch, device)` — single batch forward, loss finite, gradients non-zero
    - Implement `check_evaluation(evaluator, model, val_loader)` — AUROC computable on small subset
    - _Requirements: 15.2, 15A.1, 15A.2, 15A.3, 15A.4_

  - [x] 4.2 Implement `scripts/generate_splits.py`
    - CLI entry point accepting `--config` path
    - Load config, load dataset, generate split, run `check_data_loading` and `check_split_validity`
    - _Requirements: 2.1, 15.1_

- [x] 5. Checkpoint — Data pipeline validated
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Model architecture
  - [x] 6.1 Implement `src/models/backbone_factory.py`
    - Implement `_REGISTRY` dict, `register_backbone(name, loader)`, `create_backbone(name, weights_path)`
    - Register `"resnet50_imagenet"` — loads `torchvision.models.resnet50(weights=IMAGENET1K_V1)`, removes final FC
    - Register `"resnet50_lvmmed"` — loads ResNet50 architecture, loads state dict from weights_path, removes final FC
    - _Requirements: 3.1, 4.1, 11.3, 16.2_

  - [x] 6.2 Implement `src/models/classifier.py`
    - Implement `MultiLabelClassifier(nn.Module)` with backbone, dropout, linear head (feature_dim=2048, num_classes=6)
    - Forward returns raw logits (sigmoid applied in loss/eval)
    - _Requirements: 3.2, 16.1_

  - [x] 6.3 Write unit tests for backbone factory and classifier
    - Test ImageNet backbone creation returns correct architecture
    - Test LVM-Med backbone creation with mock weights
    - Test classifier forward pass produces correct output shape (B, 6)
    - _Requirements: 11.3, 16.2_

- [ ] 7. Training loop and losses
  - [x] 7.1 Implement `src/training/losses.py`
    - Implement masked BCE loss: `F.binary_cross_entropy_with_logits` with `reduction='none'`, element-wise multiply by loss_mask, then mean
    - Support both standard (all-ones mask) and pseudo-label (partial mask) modes
    - _Requirements: 3.2, 5.6_

  - [x] 7.2 Implement `src/training/trainer.py`
    - Implement `Trainer` class with `__init__(config, model, train_loader, val_loader, device)`
    - Implement `train()` — full training loop with epoch-level logging and checkpointing
    - Implement `_train_epoch(epoch)` — forward, masked BCE loss, backward
    - Implement `_validate(epoch)` — compute macro-AUROC and per-class AUROC on val set
    - Implement `_save_checkpoint(epoch, val_metrics)` — save best_checkpoint.pt (highest val macro-AUROC) and last_checkpoint.pt
    - Support resume from `config.training.resume_checkpoint` path
    - Log training loss and validation macro-AUROC each epoch
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3A.1, 3A.2, 3A.3, 3A.4, 3A.5, 3A.6, 12.4, 14.3_

  - [~] 7.3 Write property test: P8 — Best checkpoint tracks the maximum validation AUROC
    - **Property 8: Best checkpoint tracks the maximum validation AUROC**
    - Generate random sequences of (epoch, val_macro_auroc) pairs; verify best checkpoint corresponds to highest AUROC (latest if tied)
    - **Validates: Requirements 3A.3**

  - [x] 7.3.1 Implement `scripts/train.py`
    - CLI entry point accepting `--config` path
    - Load config, set seeds, build model, create data loaders, instantiate Trainer, run training
    - Run `check_training_step` sanity check before full training
    - Save config copy alongside checkpoints
    - _Requirements: 9.1, 10.1, 14.1, 14.2, 14.3, 14.4, 15.1_

- [x] 8. Checkpoint — Supervised baseline training validated
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 9. Pseudo-labeling pipeline
  - [x] 9.1 Implement `src/pseudo_labeling/threshold_strategy.py`
    - Implement `ThresholdStrategy` ABC with `accept(probabilities, uncertainties, class_names)` returning `(pseudo_labels, rejection_mask)`
    - Implement `PositiveOnlyStrategy` — accept pseudo-label 1.0 where prob > threshold; NaN otherwise; independent per class
    - Implement `UncertaintyFilteredStrategy` — accept where prob > conf_threshold AND uncertainty < unc_threshold; NaN otherwise
    - _Requirements: 5.2, 5.3, 5.4, 5.9, 6.3, 6.4, 11.2, 16.1_

  - [x] 9.2 Write property test: P9 — Positive-only confidence thresholding accepts only high-confidence positives
    - **Property 9: Positive-only confidence thresholding accepts only high-confidence positives**
    - Generate random (N,C) prob matrices + per-class threshold dicts; verify: 1.0 where prob > threshold, NaN otherwise, independent per class
    - **Validates: Requirements 5.2, 5.3, 5.4**

  - [x] 9.3 Implement `src/pseudo_labeling/teacher_inference.py`
    - Implement `run_teacher_inference(model, dataloader, device)` returning `(sample_indices, probabilities)` as numpy arrays
    - Standard forward pass with `torch.no_grad()` and sigmoid on logits
    - _Requirements: 5.1, 5.2_

  - [x] 9.4 Implement `src/data/combined_dataset.py`
    - Implement `CombinedDataset(torch.utils.data.Dataset)` merging labeled + pseudo-labeled samples
    - Ground-truth labels never overwritten by pseudo-labels
    - For pseudo-labeled samples, only accepted classes contribute to loss via mask tensor
    - `__getitem__` returns `(image_tensor, label_vector, loss_mask, is_pseudo)`
    - _Requirements: 5.6, 5.7, 13.1_

  - [x] 9.5 Write property test: P10 — Ground-truth labels are never overwritten by pseudo-labels
    - **Property 10: Ground-truth labels are never overwritten by pseudo-labels**
    - Generate random labeled data + pseudo-labels; merge into CombinedDataset; verify labeled samples retain original label vectors
    - **Validates: Requirements 5.7, 13.1**

  - [x] 9.6 Implement `src/pseudo_labeling/artifact_io.py`
    - Implement `save_pseudo_label_artifact(artifact_dir, sample_indices, probabilities, pseudo_labels, rejection_mask, uncertainties, config)` saving CSV + config JSON
    - Implement `load_pseudo_label_artifact(artifact_path)` returning a DataFrame
    - Directory structure: `outputs/pseudo_labels/{setting}/{ratio}_{seed}/`
    - _Requirements: 6A.1, 6A.2, 6A.3_

  - [x] 9.7 Write property test: P13 — Pseudo-label artifact round-trip persistence
    - **Property 13: Pseudo-label artifact round-trip persistence**
    - Generate random pseudo-label artifacts; save to disk and load back; verify DataFrame equality within float tolerance
    - **Validates: Requirements 6A.1, 6A.3**

  - [x] 9.8 Implement `scripts/generate_pseudo_labels.py`
    - CLI entry point accepting `--config` and `--teacher-checkpoint` paths
    - Load teacher model, run inference on unlabeled set, apply threshold strategy, save artifacts
    - Log per-class accepted/rejected counts
    - _Requirements: 5.1, 5.2, 5.8, 6A.1_

- [x] 10. Checkpoint — Pseudo-labeling pipeline validated
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 11. Uncertainty estimation (MC Dropout)
  - [x] 11.1 Implement `src/pseudo_labeling/mc_dropout.py`
    - Implement `run_mc_dropout_inference(model, dataloader, device, num_passes, uncertainty_metric)` returning `(sample_indices, mean_probabilities, uncertainties)`
    - Enable dropout at inference via `model.train()` on dropout layers only
    - Implement `compute_predictive_entropy(mc_probs)` — H = -[p·log(p) + (1-p)·log(1-p)] where p = mean over T passes
    - Validate `num_passes > 0`; raise `ValueError` if unsupported metric
    - _Requirements: 6.1, 6.2, 6.6, 6.7, 6.8_

  - [x] 11.2 Write property test: P11 — Predictive entropy computation follows the binary entropy formula
    - **Property 11: Predictive entropy computation follows the binary entropy formula**
    - Generate random (T,N,C) probability tensors in (0,1); verify entropy equals H = -[p·log(p) + (1-p)·log(1-p)] where p = mean over T
    - **Validates: Requirements 6.2**

  - [x] 11.3 Write property test: P12 — Uncertainty-filtered thresholding requires both conditions
    - **Property 12: Uncertainty-filtered thresholding requires both conditions**
    - Generate random probs, uncertainties, conf thresholds, unc thresholds; verify acceptance iff prob > conf AND uncertainty < unc
    - **Validates: Requirements 6.3, 6.4**

- [x] 12. Checkpoint — Uncertainty filtering validated
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 13. Evaluation and reporting
  - [x] 13.1 Implement `src/evaluation/metrics.py`
    - Implement `compute_auroc(y_true, y_score, label_names)` returning `{'macro_auroc': float, 'per_class_auroc': {name: float}}`
    - Implement `compute_optional_metrics(y_true, y_pred, y_score, label_names, metrics_list)` for macro_f1 and mAP
    - Use `sklearn.metrics.roc_auc_score` as reference implementation
    - _Requirements: 7.1, 7.4_

  - [x] 13.2 Write property test: P14 — AUROC computation matches reference implementation
    - **Property 14: AUROC computation matches reference implementation**
    - Generate random binary y_true and score matrices (each class has ≥1 positive and ≥1 negative); verify macro_auroc matches sklearn within 1e-6
    - **Validates: Requirements 7.1**

  - [x] 13.3 Implement `src/evaluation/evaluator.py`
    - Implement `evaluate_checkpoint(checkpoint_path, config, device)` — load model, run on val set, return all metrics
    - Store results in structured format (CSV/JSON) with setting, ratio, seed, macro_auroc, per-class auroc
    - _Requirements: 7.1, 7.2, 7.3, 11.4_

  - [x] 13.4 Implement `src/evaluation/reporting.py`
    - Implement `generate_comparison_bar_chart(results_df, output_dir)` — bar chart of macro-AUROC across 4 settings per ratio
    - Implement `generate_per_class_auroc_plot(results_df, output_dir)` — per-class AUROC comparison
    - Implement `generate_results_table(results_df, output_dir, format)` — Markdown and LaTeX summary tables
    - Save all plots as PNG in configurable output directory
    - _Requirements: 7.5, 8.1, 8.2, 8.3, 8.4_

  - [x] 13.5 Implement `scripts/evaluate.py`
    - CLI entry point accepting `--config` and `--checkpoint` paths
    - Load model, run evaluation, generate plots and tables, save results
    - _Requirements: 7.1, 7.2, 7.3, 8.1_

- [x] 14. Checkpoint — Evaluation pipeline validated
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 15. Colab notebook and integration wiring
  - [x] 15.1 Create `notebooks/colab_runner.ipynb`
    - Google Drive mount cell
    - pip install dependencies cell
    - Config selection and path setup cells
    - Cells for: generate splits, train supervised baseline, train LVM-Med, generate pseudo-labels, train student, run uncertainty filtering, evaluate all, generate reports
    - _Requirements: 12.1, 12.2, 12.3, 12.6_

  - [x] 15.2 Write integration tests
    - End-to-end supervised: train 2 epochs on tiny synthetic dataset, verify checkpoint + metrics saved
    - End-to-end pseudo-label: teacher train → inference → threshold → student train on tiny data
    - End-to-end uncertainty: teacher train → MC Dropout → filter → student train on tiny data
    - Evaluation standalone: load checkpoint, run evaluation, verify results CSV
    - Sanity checks: run all 4 sanity check functions on valid synthetic data
    - _Requirements: 3, 3A, 5, 6, 7, 11.4, 15A_

- [x] 16. Final checkpoint — All components integrated
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation after each major pipeline stage
- Property tests validate the 14 universal correctness properties from the design document
- Implementation follows the strict ordering from Requirement 15: data → supervised → LVM-Med → pseudo-labeling → uncertainty → evaluation
- The design uses Python (PyTorch, Hypothesis, scikit-learn) throughout — all code examples and tests use Python
